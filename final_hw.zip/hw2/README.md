This program acts as a linux shell using map data structures and vectors.
